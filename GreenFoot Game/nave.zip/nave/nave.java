import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class nave here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class nave extends Actor
{
    int podeAtirar=1;
    /**
     * Act - do whatever the nave wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        if(Greenfoot.isKeyDown("up")){
            move(3);
        }
        if(Greenfoot.isKeyDown("left")) {
            turn(-3);
        }
        if(Greenfoot.isKeyDown("right")){
            turn(3);
        }
        if(podeAtirar == 1){
            if(Greenfoot.isKeyDown("space")){
                podeAtirar=0;
                bola b1 = new bola();
                getWorld().addObject(b1, this.getX(), this.getY());
                b1.move(15);
                podeAtirar=1;
            }    
        }
    }
}
